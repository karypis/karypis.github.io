Look at doc/index.html for AFGEN's documentation.
