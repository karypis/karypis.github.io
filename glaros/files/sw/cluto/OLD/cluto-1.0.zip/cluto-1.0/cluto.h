/*
 * cluto.h 
 *
 * This file contains function prototypes and constant definitions 
 * for CLUTO
 *
 * Started 11/23/01
 * George
 *
 */

#ifndef __cluto_h__
#define __cluto_h__


#ifndef _MSC_VER
#define __cdecl
#endif

/*------------------------------------------------------------------------
* Function prototypes 
*-------------------------------------------------------------------------*/

#ifdef __cpluplus
extern "C" {
#endif

void __cdecl CLUTO_VP_ClusterDirect(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int crfun, int rowmodel, int colmodel, 
              float colprune, int ntrials, int niter, int seed, int dbglvl, 
              int nparts, int *part);


void __cdecl CLUTO_VP_ClusterRB(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int crfun, int rowmodel, int colmodel, 
              float colprune, int ntrials, int niter, int seed, 
              int kwayrefine, int dbglvl, int nparts, int *part);


float __cdecl CLUTO_VP_GetSolutionQuality(int nrows, int ncols, int *rowptr, int *rowind,  
               float *rowval, int crfun, int rowmodel, int colmodel, float colprune, 
               int nparts, int *part);


void __cdecl CLUTO_VP_GetClusterStats(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int rowmodel, int colmodel, float colprune, 
              int nparts, int *part, int *pwgts, 
	      float *cintsim, float *cintsdev, float *izscores, 
	      float *cextsim, float *cextsdev, float *ezscores);


void __cdecl CLUTO_VP_GetClusterFeatures(int nrows, int ncols, int *rowptr,
              int *rowind, float *rowval, int rowmodel, int colmodel, 
              float colprune, int nparts, int *part, int nfeatures,
              int *internalids, float *internalwgts, int *externalids,
              float *externalwgts);


void __cdecl CLUTO_VP_BuildTree(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int crfun, int rowmodel, int colmodel, 
              float colprune, int nparts, int *part, int *ptree);


void __cdecl CLUTO_VP_GetTreeStats(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int rowmodel, int colmodel, float colprune, 
              int nparts, int *part, int *ptree, int *pwgts,
              float *cintsim, float *cextsim);


void __cdecl CLUTO_VP_GetTreeFeatures(int nrows, int ncols, int *rowptr, int *rowind,
              float *rowval, int rowmodel, int colmodel, float colprune, 
              int nparts, int *part, int *ptree, int nfeatures, int *internalids,
              float *internalwgts, int *externalids, float *externalwgts);

#ifdef __cplusplus
}
#endif




/*------------------------------------------------------------------------
* Constant definitions 
*-------------------------------------------------------------------------*/

/* Different choices for RowModel */
#define CLUTO_ROWMODEL_NONE           1       /* Use the rows as is */
#define CLUTO_ROWMODEL_MAXTF          2       /* TF = .5 + .5(TF/max(|TF|)) */
#define CLUTO_ROWMODEL_SQRT           3       /* TF = 1+sign(TF, sqrt(|TF|)) */
#define CLUTO_ROWMODEL_LOG            4       /* TF = 1+sign(TF, log2(|TF|)) */


/* Different choices for ColModel */
#define CLUTO_COLMODEL_NONE           1       /* Use the columns as is */
#define CLUTO_COLMODEL_IDF            2       /* Scale-the columns following a binary IDF model */


/* Different cluster criterion functions */
#define CLUTO_CLFUN_I1      1       /* The I1 from the paper */
#define CLUTO_CLFUN_I2      2       /* The I2 from the paper */
#define CLUTO_CLFUN_E1      3       /* The E1 from the paper */
#define CLUTO_CLFUN_G1      4       /* The G1 from the paper */
#define CLUTO_CLFUN_G1P     5       /* The G1' from the paper */
#define CLUTO_CLFUN_H1      6       /* The H1 from the paper */
#define CLUTO_CLFUN_H2      7       /* The H2 from the paper */


/* Different dbglvl options */
#define CLUTO_DBG_PROGRESS         1       /* Show simple progress statistics */
#define CLUTO_DBG_RPROGRESS        2       /* Show simple progress statistics during refinement */


/* Cluto's version number */
#define CLUTO_VER_MAJOR         1
#define CLUTO_VER_MINOR         0

#endif
