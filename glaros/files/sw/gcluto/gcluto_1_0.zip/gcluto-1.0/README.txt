gCLUTO README
=============

For documentation see doc/index.html

FILES
-----

README.txt             help file
doc/                   directory containing documentation for gCLUTO
images/                directory containing all images for gCLUTO
linux/gcluto           Linux binary
matrices/              directory containing example matrices
windows/gcluto.exe     Microsoft Windows executable
windows/glut32.dll     GLUT Graphics Lib - required DLL for gcluto.exe 
windows/msvcrt.dll     MS C Run Time Lib - required DLL for gcluto.exe 



LOG
---
2003-11-19 gCLUTO 1.0 released
2003-09-17 gCLUTO 1.0 release candidate
2002-12-09 images added, DLLs supplied
