/*
 * Copyright 1997, Regents of the University of Minnesota
 *
 * metis.c
 *
 * This file contains the driving routine for multilevel method
 *
 * Started 8/28/94
 * George
 *
 * $Id: metis.c,v 1.2 2002/08/10 06:02:53 karypis Exp $
 *
 */

#include <metisbin.h>



/*************************************************************************
* Let the game begin
**************************************************************************/
int main(idxtype argc, char *argv[])
{
  idxtype i, nparts, OpType, options[10], nbytes;
  idxtype *part, *perm, *iperm, *sizes;
  GraphType graph;
  char filename[256];
  idxtype numflag = 0, wgtflag = 0, edgecut;


  if (argc != 11) {
    printf("Usage: %s <GraphFile> <Nparts> <Mtype> <Rtype> <IPtype> <Oflags> <Pfactor> <Nseps> <OPtype> <Options> \n",argv[0]);
    exit(0);
  }
    
  strcpy(filename, argv[1]);
  nparts = atoi(argv[2]);
  options[OPTION_CTYPE] = atoi(argv[3]);
  options[OPTION_RTYPE] = atoi(argv[4]);
  options[OPTION_ITYPE] = atoi(argv[5]);
  options[OPTION_OFLAGS] = atoi(argv[6]);
  options[OPTION_PFACTOR] = atoi(argv[7]);
  options[OPTION_NSEPS] = atoi(argv[8]);
  OpType = atoi(argv[9]); 
  options[OPTION_DBGLVL] = atoi(argv[10]);


  ReadGraph(&graph, filename, &wgtflag);
  if (graph.nvtxs <= 0) {
    printf("Empty graph. Nothing to do.\n");
    exit(0);
  }
  printf("Partitioning a graph with %d vertices and %d edges\n", graph.nvtxs, graph.nedges/2);

  METIS_EstimateMemory(&graph.nvtxs, graph.xadj, graph.adjncy, &numflag, &OpType, &nbytes);
  printf("Metis will need %d Mbytes\n", nbytes/(1024*1024));

  part = perm = iperm = NULL;

  options[0] = 1;
  switch (OpType) {
    case OP_PMETIS:
      printf("Recursive Partitioning... ------------------------------------------\n");
      part = idxmalloc(graph.nvtxs, "main: part");

      METIS_PartGraphRecursive(&graph.nvtxs, graph.xadj, graph.adjncy, graph.vwgt, graph.adjwgt, 
                               &wgtflag, &numflag, &nparts, options, &edgecut, part);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, part, graph.nvtxs, nparts)); 

      printf("  %d-way Edge-Cut: %7d\n", nparts, edgecut);
      ComputePartitionInfo(&graph, nparts, part);

      GKfree((void *)&part, LTERM);
      break;
    case OP_KMETIS:
      printf("K-way Partitioning... -----------------------------------------------\n");
      part = idxmalloc(graph.nvtxs, "main: part");

      METIS_PartGraphKway(&graph.nvtxs, graph.xadj, graph.adjncy, graph.vwgt, graph.adjwgt, 
                          &wgtflag, &numflag, &nparts, options, &edgecut, part);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, part, graph.nvtxs, nparts)); 

      printf("  %d-way Edge-Cut: %7d\n", nparts, edgecut);
      ComputePartitionInfo(&graph, nparts, part);

      GKfree((void *)&part, LTERM);
      break;
    case OP_OEMETIS:
      GKfree((void *)&graph.vwgt, &graph.adjwgt, LTERM);

      printf("Edge-based Nested Dissection Ordering... ----------------------------\n");
      perm = idxmalloc(graph.nvtxs, "main: perm");
      iperm = idxmalloc(graph.nvtxs, "main: iperm");

      METIS_EdgeND(&graph.nvtxs, graph.xadj, graph.adjncy, &numflag, options, perm, iperm);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, iperm, graph.nvtxs, 0)); 

      ComputeFillIn(&graph, iperm);

      GKfree((void *)&perm, &iperm, LTERM);
      break;
    case OP_ONMETIS:
      GKfree((void *)&graph.vwgt, &graph.adjwgt, LTERM);

      printf("Node-based Nested Dissection Ordering... ----------------------------\n");
      perm = idxmalloc(graph.nvtxs, "main: perm");
      iperm = idxmalloc(graph.nvtxs, "main: iperm");

      METIS_NodeND(&graph.nvtxs, graph.xadj, graph.adjncy, &numflag, options, perm, iperm);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, iperm, graph.nvtxs, 0)); 

      ComputeFillIn(&graph, iperm);

      GKfree((void *)&perm, &iperm, LTERM);
      break;
    case OP_ONWMETIS:
      GKfree((void *)&graph.adjwgt, LTERM);

      printf("WNode-based Nested Dissection Ordering... ---------------------------\n");
      perm = idxmalloc(graph.nvtxs, "main: perm");
      iperm = idxmalloc(graph.nvtxs, "main: iperm");

      METIS_NodeWND(&graph.nvtxs, graph.xadj, graph.adjncy, graph.vwgt, &numflag, options, perm, iperm);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, iperm, graph.nvtxs, 0)); 

      ComputeFillIn(&graph, iperm);

      GKfree((void *)&perm, &iperm, LTERM);
      break;
    case 6:
      GKfree((void *)&graph.vwgt, &graph.adjwgt, LTERM);

      printf("Node-based Nested Dissection Ordering... ----------------------------\n");
      perm = idxmalloc(graph.nvtxs, "main: perm");
      iperm = idxmalloc(graph.nvtxs, "main: iperm");
      sizes = idxmalloc(2*nparts, "main: sizes");

      METIS_NodeNDP(graph.nvtxs, graph.xadj, graph.adjncy, nparts, options, perm, iperm, sizes);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, iperm, graph.nvtxs, 0)); 

      ComputeFillIn(&graph, iperm);

      for (i=0; i<2*nparts-1; i++)
        printf("%d ", sizes[i]);
      printf("\n");

      GKfree((void *)&perm, &iperm, &sizes, LTERM);
      break;
    case 7:
      printf("K-way Vol Partitioning... -------------------------------------------\n");
      part = idxmalloc(graph.nvtxs, "main: part");

      METIS_PartGraphVKway(&graph.nvtxs, graph.xadj, graph.adjncy, graph.vwgt, NULL, 
            &wgtflag, &numflag, &nparts, options, &edgecut, part);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, part, graph.nvtxs, nparts)); 

      printf("  %d-way Volume: %7d\n", nparts, edgecut);
      ComputePartitionInfo(&graph, nparts, part);

      GKfree((void *)&part, LTERM);
      break;
    case 9:
      printf("K-way Partitioning (with vwgts)... ----------------------------------\n");
      part = idxmalloc(graph.nvtxs, "main: part");
      graph.vwgt = idxmalloc(graph.nvtxs, "main: graph.vwgt");
      for (i=0; i<graph.nvtxs; i++)
        graph.vwgt[i] = graph.xadj[i+1]-graph.xadj[i]+1;
      wgtflag = 2;

      METIS_PartGraphKway(&graph.nvtxs, graph.xadj, graph.adjncy, graph.vwgt, graph.adjwgt, 
                          &wgtflag, &numflag, &nparts, options, &edgecut, part);

      IFSET(options[OPTION_DBGLVL], DBG_OUTPUT, WritePartition(filename, part, graph.nvtxs, nparts)); 

      printf("  %d-way Edge-Cut: %7d\n", nparts, edgecut);
      ComputePartitionInfo(&graph, nparts, part);

      GKfree((void *)&part, LTERM);
      break;
    case 10:
      break;
    default:
      errexit("Unknown");
  }

  GKfree((void *)&graph.xadj, &graph.adjncy, &graph.vwgt, &graph.adjwgt, LTERM);
}  


