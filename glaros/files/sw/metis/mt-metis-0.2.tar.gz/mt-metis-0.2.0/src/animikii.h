/**
 * @file animikii.h
 * @brief Library entry points
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-07-01
 */

#ifndef ANIMIKII_H
#define ANIMIKII_H

#endif
