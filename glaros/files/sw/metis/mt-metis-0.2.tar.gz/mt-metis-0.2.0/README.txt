To build mt-metis, simply type 'make':

$ make

This should create the 'mt-metis' executable. For usage, type:

$ ./mt-metis -h

