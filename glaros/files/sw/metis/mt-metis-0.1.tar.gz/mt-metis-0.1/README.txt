Before making the program you need to either create a symbolic link to the
Metis source directory name 'metis':

$ ln -s ../metis-5.10 metis

Then simply type 'make':

$ make

This should create the 'mt-metis' executable. For usage, type:

$ ./mt-metis -h

