DomLib
======

Simple C functions.


Unit Tests
==========
<a href="https://travis-ci.org/dlasalle/domlib">
  <img src="https://travis-ci.org/dlasalle/domlib.svg?branch=master"/>
</a>
