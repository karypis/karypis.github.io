var group__bdmpimutexlist =
[
    [ "BDMPI_Entercritical", "d2/d06/group__bdmpimutexlist.html#gacf1d6a9505ccfd143bebefb9f9b14fa8", null ],
    [ "BDMPI_Exitcritical", "d2/d06/group__bdmpimutexlist.html#ga4dd48a9f3f5cd11a0a7a455be7509d7a", null ]
];