var group__bdmpisbmalloclist =
[
    [ "BDMPI_sbmalloc", "d8/dce/group__bdmpisbmalloclist.html#ga83c090dde428b6d6f05231d17f5d593d", null ],
    [ "BDMPI_sbrealloc", "d8/dce/group__bdmpisbmalloclist.html#ga661b7328c39c64e00c5592409f4948b0", null ],
    [ "BDMPI_sbfree", "d8/dce/group__bdmpisbmalloclist.html#ga042f812f9da2170ea7dd6e8a2d3adb87", null ],
    [ "BDMPI_sbload", "d8/dce/group__bdmpisbmalloclist.html#gabc7a531e960b815adc7e68bf6fa0de49", null ],
    [ "BDMPI_sbloadall", "d8/dce/group__bdmpisbmalloclist.html#ga79c0dce2513dd943a9096d0184d2999d", null ],
    [ "BDMPI_sbunload", "d8/dce/group__bdmpisbmalloclist.html#gabe7c03afba3b08bb6cd78d2faf2ba556", null ],
    [ "BDMPI_sbunloadall", "d8/dce/group__bdmpisbmalloclist.html#gaef81235de5e42b8d17a5eb4c05852f37", null ],
    [ "BDMPI_sbdiscard", "d8/dce/group__bdmpisbmalloclist.html#ga8d43b74ab57732deb27bfccb30aa92a1", null ]
];