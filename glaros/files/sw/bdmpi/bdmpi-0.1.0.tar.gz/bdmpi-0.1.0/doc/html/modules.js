var modules =
[
    [ "List of implemented MPI functions", "de/d91/group__mpiapilist.html", null ],
    [ "List of BDMPI specific functions", "d2/d93/group__bdmpiapi.html", "d2/d93/group__bdmpiapi" ]
];