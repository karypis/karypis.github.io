var group__bdmpiapi =
[
    [ "Functions for further communicator interrogation", "df/dc8/group__bdmpicommlist.html", "df/dc8/group__bdmpicommlist" ],
    [ "Functions for critical sections", "d2/d06/group__bdmpimutexlist.html", "d2/d06/group__bdmpimutexlist" ],
    [ "Functions for storage-backed memory allocation", "d8/dce/group__bdmpisbmalloclist.html", "d8/dce/group__bdmpisbmalloclist" ]
];