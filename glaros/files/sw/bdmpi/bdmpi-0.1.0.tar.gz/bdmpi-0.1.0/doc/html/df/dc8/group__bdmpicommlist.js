var group__bdmpicommlist =
[
    [ "BDMPI_Comm_lsize", "df/dc8/group__bdmpicommlist.html#gaa4068d19a9f52c4251aaa716e4012b70", null ],
    [ "BDMPI_Comm_lrank", "df/dc8/group__bdmpicommlist.html#ga60f6a5d4e24e2041afac441fe3e4fc4c", null ],
    [ "BDMPI_Comm_nsize", "df/dc8/group__bdmpicommlist.html#gab098eeea7fa3953c3a76a3dc486d1e3a", null ],
    [ "BDMPI_Comm_nrank", "df/dc8/group__bdmpicommlist.html#ga22bad15ae3140a72025d3fc2286190f0", null ],
    [ "BDMPI_Comm_rrank", "df/dc8/group__bdmpicommlist.html#ga126ea1eef5cb298293ce1941e159cb97", null ]
];