#define _LIBPARMETIS_RENAME_H_

#ifndef _LIBPARMETIS_RENAME_H_
#define _LIBPARMETIS_RENAME_H_

/* kmetis.c */
#define	Mc_Global_Partition Mc_Global_Partition__

/* mmetis.c */

/* gkmetis.c */

/* match.c */
#define	Match_Global Match_Global__
#define	Match_Local  Match_Local__
#define	CreateCoarseGraph_Global CreateCoarseGraph_Global__
#define	CreateCoarseGraph_Local  CreateCoarseGraph_Local__


/* initpart.c */
#define	Mc_InitPartition_RB Mc_InitPartition_RB__
#define	Mc_KeepPart Mc_KeepPart__

/* kwayrefine.c */
#define	Mc_ProjectPartition Mc_ProjectPartition__
#define	Mc_ComputePartitionParams Mc_ComputePartitionParams__

/* kwayfm.c */
#define	Mc_KWayFM Mc_KWayFM__

/* kwaybalance.c */
#define	Mc_KWayBalance Mc_KWayBalance__

/* remap.c */
#define	ParallelReMapGraph ParallelReMapGraph__
#define	ParallelTotalVReMap ParallelTotalVReMap__
#define	SimilarTpwgts SimilarTpwgts__

/* move.c */
#define	Mc_MoveGraph Mc_MoveGraph__
#define	CheckMGraph CheckMGraph__
#define	ProjectInfoBack ProjectInfoBack__
#define	FindVtxPerm FindVtxPerm__

/* memory.c */
#define	PreAllocateMemory PreAllocateMemory__
#define	FreeWSpace FreeWSpace__
#define	FreeCtrl FreeCtrl__
#define	CreateGraph CreateGraph__
#define	InitGraph InitGraph__
#define	FreeGraph FreeGraph__
#define FreeNonGraphFields FreeNonGraphFields__
#define	FreeInitialGraphAndRemap FreeInitialGraphAndRemap__


/************************/
/* Adaptive subroutines */
/************************/
/* ametis.c */
#define	Adaptive_Partition Adaptive_Partition__

/* rmetis.c */

/* wave.c */
#define	WavefrontDiffusion WavefrontDiffusion__

/* balancemylink.c */
#define	BalanceMyLink BalanceMyLink__

/* redomylink.c */
#define	RedoMyLink RedoMyLink__

/* initbalance.c */
#define	Balance_Partition Balance_Partition__
#define	Mc_AssembleAdaptiveGraph Mc_AssembleAdaptiveGraph__

/* mdiffusion.c */
#define	Mc_Diffusion Mc_Diffusion__
#define	ExtractGraph ExtractGraph__

/* diffutil.c */
#define	SetUpConnectGraph SetUpConnectGraph__
#define	Mc_ComputeMoveStatistics Mc_ComputeMoveStatistics__
#define	Mc_ComputeSerialTotalV Mc_ComputeSerialTotalV__
#define	ComputeLoad ComputeLoad__
#define	ConjGrad2 ConjGrad2__
#define	mvMult2 mvMult2__
#define	ComputeTransferVector ComputeTransferVector__
#define	ComputeSerialEdgeCut ComputeSerialEdgeCut__
#define	ComputeSerialTotalV ComputeSerialTotalV__

/* akwayfm.c */
#define	Mc_KWayAdaptiveRefine Mc_KWayAdaptiveRefine__

/* selectq.c */
#define	Mc_DynamicSelectQueue Mc_DynamicSelectQueue__
#define	Mc_HashVwgts Mc_HashVwgts__
#define	Mc_HashVRank Mc_HashVRank__

/* csrmatch.c */
#define	CSR_Match_SHEM CSR_Match_SHEM__

/* serial.c */
#define	Mc_SerialKWayAdaptRefine Mc_SerialKWayAdaptRefine__
#define	Mc_ComputeSerialPartitionParams Mc_ComputeSerialPartitionParams__
#define	AreAllHVwgtsBelow AreAllHVwgtsBelow__
#define	ComputeHKWayLoadImbalance ComputeHKWayLoadImbalance__
#define	SerialRemap SerialRemap__
#define	SSMIncKeyCmp SSMIncKeyCmp__
#define	Mc_Serial_FM_2WayRefine Mc_Serial_FM_2WayRefine__
#define	Serial_SelectQueue Serial_SelectQueue__
#define	Serial_BetterBalance Serial_BetterBalance__
#define	Serial_Compute2WayHLoadImbalance Serial_Compute2WayHLoadImbalance__
#define	Mc_Serial_Balance2Way Mc_Serial_Balance2Way__
#define	Mc_Serial_Init2WayBalance Mc_Serial_Init2WayBalance__
#define	Serial_SelectQueueOneWay Serial_SelectQueueOneWay__
#define	Mc_Serial_Compute2WayPartitionParams Mc_Serial_Compute2WayPartitionParams__
#define	Serial_AreAnyVwgtsBelow Serial_AreAnyVwgtsBelow__

/* weird.c */
#define	CheckInputsPartKway CheckInputsPartKway__
#define	CheckInputsPartGeomKway CheckInputsPartGeomKway__
#define	CheckInputsPartGeom CheckInputsPartGeom__
#define	CheckInputsAdaptiveRepart CheckInputsAdaptiveRepart__
#define	CheckInputsNodeND CheckInputsNodeND__
#define	PartitionSmallGraph PartitionSmallGraph__


/****************************/
/* Mesh to Dual subroutines */
/****************************/
/* mesh.c */
/* msetup.c */
#define	SetUpMesh SetUpMesh__
#define	CreateMesh CreateMesh__
#define	InitMesh InitMesh__


/************************/
/* Ordering subroutines */
/************************/
/* ometis.c */
#define	MultilevelOrder MultilevelOrder__
#define Order_Partition_Multiple Order_Partition_Multiple__
#define	Order_Partition Order_Partition__
#define	LabelSeparators LabelSeparators__
#define	CompactGraph CompactGraph__
#define	LocalNDOrder LocalNDOrder__

/* pspases.c */
#define	AssembleEntireGraph AssembleEntireGraph__


/* node_refine.c */
#define AllocateNodePartitionParams AllocateNodePartitionParams__
#define ComputeNodePartitionParams ComputeNodePartitionParams__
#define UpdateNodePartitionParams UpdateNodePartitionParams__
#define KWayNodeRefine_Greedy KWayNodeRefine_Greedy__
#define KWayNodeRefine_Greedy2 KWayNodeRefine_Greedy2__
#define KWayNodeRefine2Phase KWayNodeRefine2Phase__
#define KWayNodeRefine2Phase2 KWayNodeRefine2Phase2__
#define KWayNodeRefineInterior KWayNodeRefineInterior__
#define PrintNodeBalanceInfo PrintNodeBalanceInfo__


/* initmsection.c */
#define	InitMultisection InitMultisection__
#define	AssembleMultisectedGraph AssembleMultisectedGraph__

/* xyzpart.c */
#define	Coordinate_Partition Coordinate_Partition__
#define IRBinCoordinates IRBinCoordinates__
#define RBBinCoordinates RBBinCoordinates__
#define	SampleSort SampleSort__
#define	PseudoSampleSort PseudoSampleSort__

/***********************/
/* Utility subroutines */
/***********************/
/* fpqueue.c */
#define	FPQueueInit FPQueueInit__
#define	FPQueueReset FPQueueReset__
#define	FPQueueFree FPQueueFree__
#define	FPQueueGetSize FPQueueGetSize__
#define	FPQueueInsert FPQueueInsert__
#define	FPQueueDelete FPQueueDelete__
#define	FPQueueUpdate FPQueueUpdate__
#define	FPQueueUpdateUp FPQueueUpdateUp__
#define	FPQueueGetMax FPQueueGetMax__
#define	FPQueueSeeMaxVtx FPQueueSeeMaxVtx__
#define	FPQueueSeeMaxGain FPQueueSeeMaxGain__
#define	FPQueueGetKey FPQueueGetKey__
#define	FPQueueGetQSize FPQueueGetQSize__
#define	CheckHeapFloat CheckHeapFloat__

/* stat.c */
#define	Mc_ComputeSerialBalance Mc_ComputeSerialBalance__
#define	Mc_ComputeParallelBalance Mc_ComputeParallelBalance__
#define	Mc_PrintThrottleMatrix Mc_PrintThrottleMatrix__
#define	Mc_ComputeRefineStats Mc_ComputeRefineStats__
#define PrintPostPartInfo PrintPostPartInfo__

/* debug.c */
#define	PrintVector PrintVector__
#define	PrintVector2 PrintVector2__
#define	PrintPairs PrintPairs__
#define	PrintGraph PrintGraph__
#define	PrintGraph2 PrintGraph2__
#define	PrintSetUpInfo PrintSetUpInfo__
#define	PrintTransferedGraphs PrintTransferedGraphs__
#define	WriteMetisGraph WriteMetisGraph__

/* comm.c */
#define	CommInterfaceData CommInterfaceData__
#define	CommChangedInterfaceData CommChangedInterfaceData__
#define	GlobalSEMax GlobalSEMax__
#define	GlobalSEMaxComm GlobalSEMaxComm__
#define	GlobalSEMaxDouble GlobalSEMaxDouble__
#define	GlobalSEMin GlobalSEMin__
#define	GlobalSEMinComm GlobalSEMinComm__
#define	GlobalSESum GlobalSESum__
#define	GlobalSEMaxFloat GlobalSEMaxFloat__
#define	GlobalSEMinFloat GlobalSEMinFloat__
#define	GlobalSESumFloat GlobalSESumFloat__

/* util.c */
#define	errexit errexit__
#define	myprintf myprintf__
#define	rprintf rprintf__
#define	idxmalloc idxmalloc__
#define	ismalloc ismalloc__
#define	idxsmalloc idxsmalloc__
#define	GKmalloc GKmalloc__
#define	GKfree GKfree__
#define	iset iset__
#define	idxset iset__
#define	imax imax__
#define	imin imin__
#define	idxasum idxasum__
#define	snorm2 snorm2__
#define	sdot sdot__
#define	saxpy saxpy__
#define	ikeyvalsort_org ikeyvalsort_org__
#define	IncKeyValueCmp IncKeyValueCmp__
#define	dkeyvalsort dkeyvalsort__
#define	DecKeyValueCmp DecKeyValueCmp__
#define	BSearch BSearch__
#define	RandomPermute RandomPermute__
#define	FastRandomPermute FastRandomPermute__
#define	ispow2 ispow2__
#define	log2Int log2Int__
#define	BucketSortKeysDec BucketSortKeysDec__
#define	iamax iamax__
#define	imax_strd imax_strd__
#define	imin_strd imin_strd__
#define	samax_strd samax_strd__
#define	sfamax sfamax__
#define	samin_strd samin_strd__
#define	idxavg idxavg__
#define	savg savg__
#define	samax samax__
#define	sfavg sfavg__
#define	samax2 samax2__
#define	samin samin__
#define	idxsum isum__
#define	idxsum_strd isum_strd__
#define	idxadd idxadd__
#define	ssum ssum__
#define	ssum_strd ssum_strd__
#define	sscale sscale__
#define	saneg saneg__
#define	BetterVBalance BetterVBalance__
#define	IsHBalanceBetterTT IsHBalanceBetterTT__
#define	IsHBalanceBetterFT IsHBalanceBetterFT__
#define	myvalkeycompare myvalkeycompare__
#define	imyvalkeycompare imyvalkeycompare__
#define	saxpy2 saxpy2__
#define	GetThreeMax GetThreeMax__

/* qsort_special.c */
#define	iidxsort iidxsort__
#define	iintsort iintsort__
#define	ikeysort ikeysort__
#define	ikeyvalsort ikeyvalsort__

/* grsetup.c */
#define	SetupGraph SetupGraph__
#define	SetupCtrl SetupCtrl__
#define	ChangeNumbering ChangeNumbering__
#define	ChangeNumberingMesh ChangeNumberingMesh__
#define	GraphRandomPermute GraphRandomPermute__
#define	ComputeMoveStatistics ComputeMoveStatistics__

/* timer.c */
#define	InitTimers InitTimers__
#define	PrintTimingInfo PrintTimingInfo__
#define	PrintTimer PrintTimer__

/* setup.c */
#define	SetUp SetUp__
#define	Home_PE Home_PE__

#endif
