/*
 * Copyright 1997, Regents of the University of Minnesota
 *
 * rename.h
 *
 * This file contains header files
 *
 * Started 10/2/97
 * George
 *
 * $Id: rename.h,v 1.2 1998/09/20 17:36:13 karypis Exp $
 *
 */


/* NEW_stats.c */
#define Moc_ComputePartitionBalance	__Moc_ComputePartitionBalance


/* NEW_checkgraph.c */
#define CheckGraph	__CheckGraph


/* NEW_parmetis.c */
#define	MCMlevelRecursiveBisection2	__MCMlevelRecursiveBisection2


